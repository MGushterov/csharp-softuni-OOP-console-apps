﻿namespace BorderControl.Core
{
    public interface IEngine
    {
        void Start();
    }
}
