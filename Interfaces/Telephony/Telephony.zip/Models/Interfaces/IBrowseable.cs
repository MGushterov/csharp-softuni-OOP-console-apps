﻿namespace Telephony.Models.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public interface IBrowseable
    {
        string Browse(string url);
    }
}
