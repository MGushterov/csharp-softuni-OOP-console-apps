﻿namespace BirthdayCelebrations.Core
{
    public interface IEngine
    {
        void Start();
    }
}
