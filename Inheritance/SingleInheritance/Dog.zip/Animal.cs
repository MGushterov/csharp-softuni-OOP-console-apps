﻿namespace Farm
{
    using System;
    internal class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
