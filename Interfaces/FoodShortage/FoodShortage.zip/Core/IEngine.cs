﻿namespace FoodShortage.Core
{
    public interface IEngine
    {
        void Start();
    }
}
