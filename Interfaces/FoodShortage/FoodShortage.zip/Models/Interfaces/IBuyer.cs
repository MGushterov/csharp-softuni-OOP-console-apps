﻿namespace FoodShortage.Models.Interfaces
{
    public interface IBuyer
    {
        int Food => 0;

        void BuyFood();
    }
}
