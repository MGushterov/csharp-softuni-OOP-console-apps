﻿namespace Farm
{
    using System;
    internal class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
