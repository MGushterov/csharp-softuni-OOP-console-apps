﻿namespace FoodShortage.Models.Interfaces
{
    public interface IHuman : IBuyer, INameable
    {
    }
}
